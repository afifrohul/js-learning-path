import { Router } from "express";

import users from "../services/users/routes/index.js";
import authentications from "../services/authentications/routes/index.js";
import categories from "../services/categories/routes/index.js";
import companies from "../services/companies/routes/index.js";
import jobs from "../services/jobs/routes/index.js";
import applications from "../services/applications/routes/index.js";
import bookmarks from "../services/bookmarks/routes/index.js";
import profiles from "../services/profiles/routes/index.js";
import uploads from "../services/uploads/routes/index.js";

const router = Router();

router.get("/", (req, res) => {
  return res.json({
    status: "success",
    message: "Backend server successfully running!",
  });
});

router.use("/", users);
router.use("/", authentications);
router.use("/", companies);
router.use("/", categories);
router.use("/", jobs);
router.use("/", applications);
router.use("/", bookmarks);
router.use("/", profiles);
router.use("/", uploads);

export default router;
